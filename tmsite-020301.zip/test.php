<?php
$txt = "PHP";
echo "I love $txt!";
?>